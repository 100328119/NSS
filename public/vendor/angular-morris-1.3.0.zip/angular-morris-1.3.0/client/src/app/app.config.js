(function () {
    'use strict';
    /**
     * @ngdoc object
     * @name angular-morris.config
     **/
    angular.module('angular-morris').config( /*@ngInject*/ function ($locationProvider) {
        //disables html5Mode because we run in Github Pages
       // $locationProvider.html5Mode({ enabled: false });

    });
})();