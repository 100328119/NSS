(function () {
    'use strict';
    /**
    * @ngdoc object
    * @name home
    * @requires appfy.page.factory:$page
    * @requires setting
    **/
    angular.module('home', [
        //module dependencies goes here
    ]);
})();